import React from 'react';
import Post from './components/post/Post';

const App = () => {
  return (
    <>
      <Post />
    </>
  );
};

export default App;
